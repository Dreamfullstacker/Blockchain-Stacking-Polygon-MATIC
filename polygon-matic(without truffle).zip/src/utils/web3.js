import Web3 from 'web3';
import contractAbi from '../config/abi.json'
import { toast } from 'react-toastify';

let Contract = require("web3-eth-contract");
Contract.setProvider("https://data-seed-prebsc-1-s1.binance.org:8545")

export const connectToWallet = async () => {//connect the metamask using web3 and get current user account
    let web3;
    try {
        if (window.ethereum) {
            web3 = new Web3(window.ethereum)
            await window.ethereum.request({ method: 'eth_requestAccounts' })
        } else if (window.web3) {
            web3 = new Web3(window.web3.currentProvider || "https://data-seed-prebsc-1-s1.binance.org:8545")
        }
        const accounts = await web3.eth.getAccounts();
        return accounts[0]
    } catch (error) {
        // console.log("Error: ", error)
        return false
    }
}

export const getWeb3 = async () => {//first connect the EVM and return web3 instance. always use!
    let web3;
    if (window.ethereum) {
        web3 = new Web3(window.ethereum);
    } else if (window.web3) {
        await window.web3.currentProvider.enable();
        web3 = new Web3(window.web3.currentProvider);
    } else {
        console.log('No web3 instance detected.');
        return false;
    }
    return web3;
}

export const web3_contact_balance = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        // const res = await extraMaticContract.methods.getSiteInfo().call()
        // console.log(res)
        const res = await extraMaticContract.methods.getSiteInfo().call()._contractBalance//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const web3_total_deposit = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        toast.error("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        const res = await extraMaticContract.methods.getSiteInfo().call()._totalInvested//get total staked money value
        let total_deposit = web3.utils.fromWei(res)
        return total_deposit 
       
    } catch (e) {
        return false;
    }
}

export const web3_user_deposit_count = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(res)
        const res = await extraMaticContract.methods.getUserAmountOfDeposits().call()//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const web3_user_total_deposit = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        // const res = await extraMaticContract.methods.getSiteInfo().call()
        // console.log(res)
        const res = await extraMaticContract.methods.getUserInfo().call().totalDeposit//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const web3_user_total_withdraw = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        // const res = await extraMaticContract.methods.getSiteInfo().call()
        // console.log(res)
        const res = await extraMaticContract.methods.getUserInfo().call().totalWithdrawn//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const web3_user_referral_bonus = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        // const res = await extraMaticContract.methods.getSiteInfo().call()
        // console.log(res)
        const res = await extraMaticContract.methods.getUserReferralTotalBonus().call()//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const web3_referred_users = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        console.log("No web3 instance found.");
        return false;
    }
    try {
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );//create instance of contract with abi and address
        // console.log(extraMaticContract)
        // const res = await extraMaticContract.methods.getSiteInfo().call()
        // console.log(res)
        const res = await extraMaticContract.methods.getUserTotalReferrals().call()//get total staked money value
        let contact_balance = web3.utils.fromWei(res)
        return contact_balance 
       
    } catch (e) {
        return false;
    }
}

export const stakeMATIC = async (amount, planId) => {//stake amount of BNB to the planId's plan
    const web3 = await getWeb3();
    if (!web3) {
        toast.error("No web3 instance found.");
        return false;
    }
    try {
        let connectedAddress = await connectToWallet();
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );
        const txCount = await web3.eth.getTransactionCount(connectedAddress);
        let referrer = process.env.REACT_APP_WEB3_TERRIORY_WALLET
        console.log(referrer);
        const myNewData = await extraMaticContract.methods.invest(referrer, planId).encodeABI()
        let weiPrice = web3.utils.toWei(`${amount}`, 'ether');
        const gas2 = await web3.eth.getGasPrice()
        const transactionParameters = {
            nonce: web3.utils.toHex(txCount),
            gasPrice: web3.utils.toHex(gas2),
            // gasLimit: web3.utils.toHex(gasLimit),
            to: process.env.REACT_APP_CONTRACT_ADDRESS ,
            from: connectedAddress,
            data: myNewData,
            value: web3.utils.toHex(weiPrice)
        }

        // As with any RPC call, it may throw an error
        const txHash = await window.ethereum.request({
            method: 'eth_sendTransaction',
            params: [transactionParameters],
        });
        
        if (txHash) {
            toast.success("Transaction Done Successfully.");
        }
    } catch (e) {
        toast.error(e.message);
        return false;
    }
}

export const WithdrawFn = async () => {
    const web3 = await getWeb3();
    if (!web3) {
        toast.error("No web3 instance found.");
        return false;
    }
    try {
        let connectedAddress = await connectToWallet();
        let extraMaticContract = new Contract(contractAbi, process.env.REACT_APP_CONTRACT_ADDRESS );
        const txCount = await web3.eth.getTransactionCount(connectedAddress);//get total trasaction count sent by current address
        const myNewData = await extraMaticContract.methods.withdraw().encodeABI()
        const gas2 = await web3.eth.getGasPrice()
        const transactionParameters = {
            nonce: web3.utils.toHex(txCount),
            gasPrice: web3.utils.toHex(gas2),
            // gasLimit: web3.utils.toHex(gasLimit),
            to: process.env.REACT_APP_CONTRACT_ADDRESS,
            from: connectedAddress,
            data: myNewData,
        }
        // As with any RPC call, it may throw an error
        const txHash = await window.ethereum.request({
            method: 'eth_sendTransaction',
            params: [transactionParameters],
        });
        if (txHash) {
            toast.success("Transaction Done Successfully.");
            return
        }
    } catch (e) {
        toast.error(e.message);
        return false;
    }
}
